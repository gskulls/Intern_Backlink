<?php
/*
Plugin Name: InternalBacklink
Description: Automatically adds internal backlinks to articles
Version: 1.0
Author: Marc Williams
* Author URI: https://www.facebook.com/marcwilliams011
*/


function internal_backlink_handler($content) {
    // Keywords to search for
    $keywords = array('afrobeats', 'hip hop', 'pop', 'football');
    //change the keywords to your preferred keyword you want to backlink to
  
    // Set up a flag variable for each keyword
    $backlinked_keywords = array();
    foreach ($keywords as $keyword) {
      $backlinked_keywords[$keyword] = false;
    }
  
    foreach ($keywords as $keyword) {
      // Check if the keyword has already been backlinked
      if (!$backlinked_keywords[$keyword]) {
        // Search for the keyword in the content
        if (stripos($content, $keyword) !== false) {
          // Keyword found, so let's retrieve a list of articles with the keyword
          $args = array(
            'post_type' => 'post',
            'posts_per_page' => -1,
            's' => $keyword
          );
          $query = new WP_Query($args);
          if ($query->have_posts()) {
            // Go through each post and create a backlink for each one
            foreach ($query->posts as $post) {
              // Create a backlink to the article using the keyword as the anchor text
              $backlink = '<a href="' . get_permalink($post->ID) . '">' . $keyword . '</a>';
              // Replace the keyword with the backlink, using the word boundary anchor to match only solo keywords
              $content = preg_replace("/\b$keyword\b/i", $backlink, $content, 1);
            }
            // Set the flag to indicate that the keyword has been backlinked
            $backlinked_keywords[$keyword] = true;
          }
        }
      }
    }
    return $content;
  }
  
  add_filter('the_content', 'internal_backlink_handler');
  